<link href="hybrid.css" rel="stylesheet"></link>

# 知乎

发现更大的世界。

## 更大的

饮水思源。[google](www.google.com)

## 世界

最新动态。

$$e^{i\pi}=-1$$

这就是世界。

## 语言

你好世界。`print`是最常用的命令之一^[or not?]。

~~~{.c}
print "hello world!"
~~~

> 这里是引用的一段话。这里是引用的一段话。这里是引用的一段话。这里是引用的一段话。
> 
> This is a block quote. This is a block quote. This is a block quote. 
> This is a block quote. This is a block quote. This is a block quote. This 
> is a block quote. 
> 
> 引用结束。

* 列表1
* 买菜
* cooking

1. six god
2. Longman